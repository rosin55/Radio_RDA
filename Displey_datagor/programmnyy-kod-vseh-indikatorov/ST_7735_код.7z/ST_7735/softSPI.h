#ifndef _SOFT_SPI_H_
#define _SOFT_SPI_H_

#include <avr/io.h>
#include <util/delay.h>

#define cbi(_byte, _bit)      _byte &= ~(1<<_bit)
#define sbi(_byte, _bit)      _byte |=  (1<<_bit)

#define RESET_HW

#define ST_DDR                DDRB
#define ST_PORT               PORTB
#define ST_PIN                PINB
#define SCK_pin               PB4
#define MOSI_pin              PB3
#define DC_pin                PB2
#define CS_pin                PB1
#ifdef RESET_HW
  #define RESET_HW_pin        PB0
  #define RESET_HW_DELAY      10
#endif

#define MSBit                 0x80
#define LSBit                 0x01

void spiInit(void);
void spiWriteByte(uint8_t _byte);

#endif /* _SOFT_SPI_H_ */     
