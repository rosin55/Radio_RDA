#include "softSPI.h"
#include "st7735.h"
#include "graphics.h"
#include "charge.c"
#include "android.c"
#include "ArialNarrow14.c"

int main(void) 
{
 st7735_init();
 st7735_fill_screen(BLACK);

 setCursor(100, 140);
 setColor(YELLOW);
 drawIcon(charge); 
 
 setCursor(0, 30);
 setColor(RED);
 drawIcon(android); 

 setCursor(4, 4);
 setColor(WHITE);
 drawRectangle(120, 152);

 setColor(GREEN);
 setFont(ArialNarrow14);  
 setCursor(20, 6);
 printString("�������");

 while(1) 
    {

	}
}
