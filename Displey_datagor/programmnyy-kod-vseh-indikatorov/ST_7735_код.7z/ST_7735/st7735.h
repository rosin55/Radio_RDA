#ifndef _ST7735_H_
#define _ST7735_H_

#include "softSPI.h"

#define ST7735_TFTWIDTH       128
#define ST7735_TFTHEIGHT      160

#define BLACK                   0x0000
#define BLUE                    0x001F
#define RED                     0xF800
#define GREEN                   0x07E0
#define CYAN                    0x07FF
#define MAGENTA                 0xF81F
#define YELLOW                  0xFFE0  
#define WHITE                   0xFFFF

#define ST7735_RESET_SW         0x01
#define ST7735_SLPOUT           0x11
#define ST7735_DISPON           0x29

#define ST7735_COLMOD           0x3A
  #define COLMOD_16_BIT       0x05
#define ST7735_MADCTL           0x36
  #define MADCTL_MY           0x80
  #define MADCTL_MX           0x40
  #define MADCTL_MV           0x20
  #define MADCTL_ML           0x10
  #define MADCTL_RGB          0x00
  #define MADCTL_BGR          0x08
  #define MADCTL_MH           0x04
  
#define ST7735_CASET            0x2A
#define ST7735_RASET            0x2B
#define ST7735_RAMWR            0x2C

void st7735_command(uint8_t command);
void st7735_data(uint8_t data);
void st7735_reset_hw(void);
void st7735_reset_sw(void);
void st7735_init(void);
void st7735_set_rotation(uint8_t rotation);
void st7735_fill_screen(uint16_t color);
void draw_pixel(uint16_t x, uint16_t y, uint16_t color);

#endif /* _ST7735_H_ */  
