#include "ili9481.h"

void ili9481_reset_sw(void)          
{
  ili9481_write_command(ILI9481_SOFTRESET); 
  _delay_ms(120);
}  

void ili9481_reset_hw(void)          
{
  #ifdef RESET_HW
    cbi(CONTROL_PORT, RST_pin); 
    _delay_us(RST_HW_DELAY);    
    sbi(CONTROL_PORT, RST_pin); 
    _delay_ms(120);               
  #endif                                    
}

void ili9481_init(void)
{
  parallel_8_init();
  
  cbi(CONTROL_PORT, CS_pin); 
  
  #ifndef RESET_HW
    ili9481_reset_sw();     
  #else
    ili9481_reset_hw();      
  #endif   

  ili9481_write_command(ILI9481_MADCTL);
   ili9481_write_parametr(MADCTL_PARAMETER);
  ili9481_write_command(ILI9481_COLMOD);
    ili9481_write_parametr(COLMOD_PARAMETER);
  ili9481_write_command(ILI9481_SLEEPOUT);
  _delay_ms(120);               
  ili9481_write_command(ILI9481_DISPLAYON);
  _delay_ms(120);    

  sbi(CONTROL_PORT, CS_pin);           
}

void ili9481_fill_screen(uint16_t color)
{
  cbi(CONTROL_PORT, CS_pin); 
  
  ili9481_write_command(ILI9481_COLADDRSET); 
    ili9481_write_parametr(0x00); ili9481_write_parametr(0x00); 
    ili9481_write_parametr((ILI9481_TFTWIDTH - 1) >> 8); ili9481_write_parametr(ILI9481_TFTWIDTH - 1);
  ili9481_write_command(ILI9481_PAGEADDRSET); 
    ili9481_write_parametr(0x00); ili9481_write_parametr(0x00); 
    ili9481_write_parametr((ILI9481_TFTHEIGHT - 1) >> 8); ili9481_write_parametr(ILI9481_TFTHEIGHT - 1);

  ili9481_write_command(ILI9481_MEMORYWRITE);  
  for(uint32_t counter = 0; counter < ((uint32_t)ILI9481_TFTWIDTH * (uint32_t)ILI9481_TFTHEIGHT); counter++)
    {
      ili9481_write_data(color); 
    }
    
  sbi(CONTROL_PORT, CS_pin);     
}

void draw_pixel(uint16_t x, uint16_t y, uint16_t color)
{
  cbi(CONTROL_PORT, CS_pin); 
  
  ili9481_write_command(ILI9481_COLADDRSET); 
    ili9481_write_parametr(x >> 8); ili9481_write_parametr(x); 
    ili9481_write_parametr((x + 1) >> 8); ili9481_write_parametr(x + 1);
  ili9481_write_command(ILI9481_PAGEADDRSET); 
    ili9481_write_parametr(y >> 8); ili9481_write_parametr(y); 
    ili9481_write_parametr((y + 1) >> 8); ili9481_write_parametr(y + 1);

  ili9481_write_command(ILI9481_MEMORYWRITE);  
    ili9481_write_data(color);  
    
  sbi(CONTROL_PORT, CS_pin);     
}

uint16_t ili9481_readID(void)
{
  uint8_t parametr;
  uint16_t id;
   
  cbi(CONTROL_PORT, CS_pin); 
  ili9481_write_command(ILI9481_READ_ID); 
    ili9481_read_parametr(parametr);   
    ili9481_read_parametr(parametr);   
    ili9481_read_parametr(parametr);   
    ili9481_read_parametr(parametr);   
      id = parametr;
      id <<= 8;
    ili9481_read_parametr(parametr);   
      id |= parametr;
    ili9481_read_parametr(parametr);       
  sbi(CONTROL_PORT, CS_pin); 

  return id;
}
