/* File parallel_8.h */
#ifndef PARALLEL_8_H
#define PARALLEL_8_H

#include<avr/io.h>

#define CONTROL_PORT        PORTC
#define CONTROL_DDR         DDRC
#define RD_pin              PC0  
#define WR_pin              PC1
#define DC_pin              PC2    
#define CS_pin              PC3
#define RESET_HW 
#ifdef RESET_HW
  #define RST_pin           PC4
  #define RST_HW_DELAY      10
#endif

#define LCD_LOW_PORT        PORTB  
#define LCD_LOW_DDR         DDRB  
#define LCD_LOW_PIN         PINB  
#define LCD_D0_pin          PB0
#define LCD_D1_pin          PB1
#define LCD_LOW_MASK        0b00000011

#define LCD_HIGH_PORT       PORTD 
#define LCD_HIGH_DDR        DDRD  
#define LCD_HIGH_PIN        PIND   
#define LCD_D2_pin          PD2
#define LCD_D3_pin          PD3
#define LCD_D4_pin          PD4
#define LCD_D5_pin          PD5
#define LCD_D6_pin          PD6
#define LCD_D7_pin          PD7
#define LCD_HIGH_MASK       0b11111100

#define cbi(_byte, _bit)    _byte &= ~(1<<_bit)
#define sbi(_byte, _bit)    _byte |=  (1<<_bit)

#define write_byte(_byte)                                                       \
  {                                                                             \
    LCD_HIGH_PORT = (LCD_HIGH_PORT & LCD_LOW_MASK) | ((_byte) & LCD_HIGH_MASK); \
    LCD_LOW_PORT  = (LCD_LOW_PORT & LCD_HIGH_MASK) | ((_byte) & LCD_LOW_MASK);  \
    cbi(CONTROL_PORT, WR_pin);                                                  \
    sbi(CONTROL_PORT, WR_pin);                                                  \
  }

#define read_byte(_byte)                                                   \
  {                                                                        \
    cbi(CONTROL_PORT, RD_pin);                                             \
    _delay_us(10);                                                         \
    _byte = (LCD_HIGH_PIN & LCD_HIGH_MASK) | (LCD_LOW_PIN & LCD_LOW_MASK); \
    sbi(CONTROL_PORT, RD_pin);                                             \
  }

#define set_write_dir()             \
  {                                 \
    LCD_HIGH_DDR |=  LCD_HIGH_MASK; \
    LCD_LOW_DDR |=  LCD_LOW_MASK;   \
  }

#define set_read_dir()              \
  {                                 \
    LCD_HIGH_DDR &= ~LCD_HIGH_MASK; \
    LCD_LOW_DDR &= ~LCD_LOW_MASK;   \
  }

void parallel_8_init(void);

#endif /* PARALLEL_8_H */
