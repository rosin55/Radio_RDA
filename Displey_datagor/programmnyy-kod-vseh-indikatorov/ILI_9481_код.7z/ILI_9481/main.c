#include "parallel_8.h"
#include "ili9481.h"
#include "graphics.h"
#include "android.c"
#include "youtube.c"
#include "Verdana20.c"

int main(void) 
{
  ili9481_init();  
  ili9481_fill_screen(BLACK);

  setColor(WHITE);
  setCursor(15, 25);
  fillRectangle(204, 204);

  setColor(RED);
  setCursor(15, 25);
  drawIcon(youtube);

  setColor(GREEN);
  setCursor(280, 70);
  drawIcon(android);

  setFont(Verdana20);  
  setCursor(280, 40);
  printString("Hello!");

  setColor(YELLOW);
  setCursor(120, 270);
  printString("�����������");

	while(1) {

	}
}
