/* File ili9481.h */
#ifndef ILI_9481_H
#define ILI_9481_H

#include<util/delay.h>
#include <stdint.h> 
#include "parallel_8.h"

#define BLACK                       0x0000
#define BLUE                        0x001F
#define RED                         0xF800
#define GREEN                       0x07E0
#define CYAN                        0x07FF
#define MAGENTA                     0xF81F
#define YELLOW                      0xFFE0  
#define WHITE                       0xFFFF

#define ILI9481_SOFTRESET           0x01
#define ILI9481_SLEEPOUT            0x11
#define ILI9481_DISPLAYOFF          0x28
#define ILI9481_DISPLAYON           0x29
#define ILI9481_COLADDRSET          0x2A
#define ILI9481_PAGEADDRSET         0x2B
#define ILI9481_MEMORYWRITE         0x2C
#define ILI9481_MADCTL              0x36
  #define MADCTL_MY             0x80
  #define MADCTL_MX             0x40
  #define MADCTL_MV             0x20
  #define MADCTL_ML             0x10
  #define MADCTL_BGR            0x08
  #define MADCTL_RGB            0x00    
  #define MADCTL_MHF            0x02
  #define MADCTL_MVF            0x01  
#define ILI9481_COLMOD              0x3A
  #define COLMOD_PARAMETER      0x55
#define ILI9481_READ_ID             0xBF

#define ROTATION                    4
#if ROTATION == 1    
  #define MADCTL_PARAMETER          MADCTL_MHF | MADCTL_BGR
  #define ILI9481_TFTWIDTH          320
  #define ILI9481_TFTHEIGHT         480
#elif ROTATION == 2
  #define MADCTL_PARAMETER          MADCTL_MV | MADCTL_BGR
  #define ILI9481_TFTWIDTH          480
  #define ILI9481_TFTHEIGHT         320
#elif ROTATION == 3
  #define MADCTL_PARAMETER          MADCTL_MVF | MADCTL_BGR
  #define ILI9481_TFTWIDTH          320
  #define ILI9481_TFTHEIGHT         480
#elif ROTATION == 4
  #define MADCTL_PARAMETER          MADCTL_MVF | MADCTL_MHF | MADCTL_MV | MADCTL_BGR
  #define ILI9481_TFTWIDTH          480
  #define ILI9481_TFTHEIGHT         320  
#endif  

#define ili9481_write_command(command)   \
  {                                      \
    cbi(CONTROL_PORT, DC_pin);           \
    write_byte(command);                 \
    cbi(CONTROL_PORT, WR_pin);           \
    sbi(CONTROL_PORT, WR_pin);           \
  }  

#define ili9481_write_data(data)         \
  {                                      \
    sbi(CONTROL_PORT, DC_pin);           \
    write_byte(data >> 8);               \
    write_byte(data);                    \
  }

#define ili9481_write_parametr(parametr) \
  {                                      \
    sbi(CONTROL_PORT, DC_pin);           \
    write_byte(parametr);                \
  }

#define ili9481_read_parametr(parametr) \
  {                                     \
    set_read_dir();                     \
    sbi(CONTROL_PORT, DC_pin);          \
    read_byte(parametr);                \
    set_write_dir();                    \
  }

void ili9481_reset_sw(void);
void ili9481_reset_hw(void);
void ili9481_init(void);      
void ili9481_fill_screen(uint16_t color);      
void draw_pixel(uint16_t x, uint16_t y, uint16_t color);
uint16_t ili9481_readID(void);

#endif /* ILI_9481_H */
