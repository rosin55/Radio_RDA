#include "ili9341.h"

void ili9341_reset_sw(void)          
{
  ili9341_write_command(ILI9341_SOFTRESET); 
  _delay_ms(120);
}  

void ili9341_reset_hw(void)          
{
  #ifdef RESET_HW
    cbi(CONTROL_PORT, RESET_HW_pin); 
    _delay_us(RESET_HW_DELAY);    
    sbi(CONTROL_PORT, RESET_HW_pin); 
    _delay_ms(120);               
  #endif                                    
}

void ili9341_init(void)
{
  parallel_8_init();
  cbi(CONTROL_PORT, CS_pin); 
  
  #ifndef RESET_HW
    ili9341_reset_sw();     
  #else
    ili9341_reset_hw();      
  #endif   

  ili9341_write_command(ILI9341_COLMOD);
    ili9341_write_parametr(COLMOD_PARAMETR);
  ili9341_write_command(ILI9341_MADCTL);
   ili9341_write_parametr(MADCTL_PARAMETR);
  ili9341_write_command(ILI9341_SLEEPOUT);
  _delay_ms(120);               
  ili9341_write_command(ILI9341_DISPLAYON);
  _delay_ms(120);               
      
  sbi(CONTROL_PORT, CS_pin); 
}

void ili9341_fill_screen(uint16_t color)
{
  cbi(CONTROL_PORT, CS_pin); 
  
  ili9341_write_command(ILI9341_COLADDRSET); 
    ili9341_write_parametr(0x00); ili9341_write_parametr(0x00); 
    ili9341_write_parametr((ILI9341_TFTWIDTH - 1) >> 8); ili9341_write_parametr(ILI9341_TFTWIDTH - 1);
  ili9341_write_command(ILI9341_PAGEADDRSET); 
    ili9341_write_parametr(0x00); ili9341_write_parametr(0x00); 
    ili9341_write_parametr((ILI9341_TFTHEIGHT - 1) >> 8); ili9341_write_parametr(ILI9341_TFTHEIGHT - 1);

  ili9341_write_command(ILI9341_MEMORYWRITE);  
  for(uint32_t counter = 0; counter < ((uint32_t)ILI9341_TFTWIDTH * (uint32_t)ILI9341_TFTHEIGHT); counter++)
    {
      ili9341_write_data(color); 
    }
    
  sbi(CONTROL_PORT, CS_pin);     
}

void draw_pixel(int16_t x, int16_t y, uint16_t color)
{
  cbi(CONTROL_PORT, CS_pin); 
  
  ili9341_write_command(ILI9341_COLADDRSET); 
    ili9341_write_parametr(x >> 8); ili9341_write_parametr(x); 
    ili9341_write_parametr((x + 1) >> 8); ili9341_write_parametr(x + 1);
  ili9341_write_command(ILI9341_PAGEADDRSET); 
    ili9341_write_parametr(y >> 8); ili9341_write_parametr(y); 
    ili9341_write_parametr((y + 1) >> 8); ili9341_write_parametr(y + 1);

  ili9341_write_command(ILI9341_MEMORYWRITE);  
    ili9341_write_data(color);  
    
  sbi(CONTROL_PORT, CS_pin);     
}

uint16_t ili9341_readID(void)
{
  uint8_t parametr;
  uint16_t id;
   
  cbi(CONTROL_PORT, CS_pin); 
  ili9341_write_command(ILI9341_READ_ID4); 
    ili9341_read_parametr(parametr);   
    ili9341_read_parametr(parametr);   
    ili9341_read_parametr(parametr);   
      id = parametr;
      id <<= 8;
    ili9341_read_parametr(parametr);   
      id |= parametr;
  sbi(CONTROL_PORT, CS_pin); 

  return id;
}

