/* File ili9341.h*/
#ifndef ILI9341_H
#define ILI9341_H

#include<util/delay.h>
#include <stdint.h> 
#include "parallel_8.h"

#define BLACK                       0x0000
#define BLUE                        0x001F
#define RED                         0xF800
#define GREEN                       0x07E0
#define CYAN                        0x07FF
#define MAGENTA                     0xF81F
#define YELLOW                      0xFFE0  
#define WHITE                       0xFFFF

#define ILI9341_SOFTRESET           0x01
#define ILI9341_SLEEPOUT            0x11
#define ILI9341_DISPLAYON           0x29
#define ILI9341_COLADDRSET          0x2A
#define ILI9341_PAGEADDRSET         0x2B
#define ILI9341_MEMORYWRITE         0x2C
#define ILI9341_MADCTL              0x36
  #define MADCTL_MY               0x80
  #define MADCTL_MX               0x40
  #define MADCTL_MV               0x20
  #define MADCTL_ML               0x10
  #define MADCTL_BGR              0x08
  #define MADCTL_RGB              0x00    
  #define MADCTL_MH               0x04
#define ILI9341_COLMOD              0x3A
  #define COLMOD_PARAMETR           0x55
#define ILI9341_READ_ID4            0xD3

#define ROTATION                    4
#if ROTATION == 1    
  #define MADCTL_PARAMETR           MADCTL_MX | MADCTL_BGR
  #define ILI9341_TFTWIDTH          240
  #define ILI9341_TFTHEIGHT         320
#elif ROTATION == 2
  #define MADCTL_PARAMETR           MADCTL_MV | MADCTL_BGR
  #define ILI9341_TFTWIDTH          320
  #define ILI9341_TFTHEIGHT         240
#elif ROTATION == 3
  #define MADCTL_PARAMETR           MADCTL_MY | MADCTL_BGR
  #define ILI9341_TFTWIDTH          240
  #define ILI9341_TFTHEIGHT         320
#elif ROTATION == 4
  #define MADCTL_PARAMETR           MADCTL_MX | MADCTL_MY| MADCTL_MV | MADCTL_BGR
  #define ILI9341_TFTWIDTH          320
  #define ILI9341_TFTHEIGHT         240  
#endif 

#define ili9341_write_command(command)   \
  {                                      \
    cbi(CONTROL_PORT, DC_pin);           \
    write_byte(command);                 \
  }  

#define ili9341_write_parametr(parametr) \
  {                                      \
    sbi(CONTROL_PORT, DC_pin);           \
    write_byte(parametr);                \
  }

#define ili9341_write_data(data)         \
  {                                      \
    sbi(CONTROL_PORT, DC_pin);           \
    write_byte(data >> 8);               \
    write_byte(data);                    \
  }

#define ili9341_read_parametr(parametr) \
  {                                     \
    set_read_dir();                     \
    sbi(CONTROL_PORT, DC_pin);          \
    read_byte(parametr);                \
    set_write_dir();                    \
  }

void ili9341_reset_sw(void);
void ili9341_reset_hw(void);
void ili9341_init(void);      
void ili9341_fill_screen(uint16_t color);      
void draw_pixel(int16_t x, int16_t y, uint16_t color);
uint16_t ili9341_readID(void);

#endif /* ILI9341_H */
