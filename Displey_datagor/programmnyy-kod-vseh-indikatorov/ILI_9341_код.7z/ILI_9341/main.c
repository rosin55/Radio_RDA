#include "parallel_8.h"
#include "ili9341.h"
#include "graphics.h"
#include "charge.c"
#include "android.c"
#include "youtube.c"
#include "Verdana20.c"

int main(void) 
{
  ili9341_init();
  ili9341_fill_screen(BLUE);

  setCursor(17, 17);
  setColor(YELLOW);
  fillRectangle(204, 204);
  
  setCursor(17, 17);
  setColor(BLACK);
  drawIcon(youtube);

  setCursor(260, 120);
  setColor(YELLOW);
  drawIcon(charge);  

  setCursor(300, 80);
  setColor(GREEN);
  drawIcon(android);  

  setFont(Verdana20);  
  setColor(WHITE);
  setCursor(80, 250);
  printString("������������");


	while(1) {

	}
}
