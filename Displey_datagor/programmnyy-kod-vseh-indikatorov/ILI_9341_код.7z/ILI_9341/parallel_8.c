#include "parallel_8.h"

void parallel_8_init(void)
{
  CONTROL_DDR  = (1 << RD_pin) | (1 << WR_pin) | (1 << DC_pin) | (1 << CS_pin);
  CONTROL_PORT = (1 << RD_pin) | (1 << WR_pin) | (1 << DC_pin) | (1 << CS_pin);

  #ifdef RESET_HW
    CONTROL_DDR  |= (1 << RESET_HW_pin);
    CONTROL_PORT |= (1 << RESET_HW_pin);
  #endif
  
  set_write_dir();
}
